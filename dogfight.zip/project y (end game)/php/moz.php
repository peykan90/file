<?php
$favoriteColor = "آبی";

echo "<h2>برنامه تشخیص رنگ مورد علاقه</h2>";

switch($favoriteColor) {
    case "قرمز":
        echo "رنگ مورد علاقه شما <strong>قرمز</strong> است! ";
        break;
    
    case "آبی":
        echo "رنگ مورد علاقه شما <strong>آبی</strong> است! ";
        break;
    
    case "سبز":
        echo "رنگ مورد علاقه شما <strong>سبز</strong> است! ";
        break;
    
    case "زرد":
        echo "رنگ مورد علاقه شما <strong>زرد</strong> است! ";
        break;
    
    case "مشکی":
        echo "رنگ مورد علاقه شما <strong>مشکی</strong> است! ";
        break;
    
    case "سفید":
        echo "رنگ مورد علاقه شما <strong>سفید</strong> است! ";
        break;
    
    default:
        echo "رنگ مورد علاقه شما در لیست ما نیست!";
}
echo "<br>";


$car = array("تخم مرغ", "ارابه مرگ", "واشر زن", "هرچی دوست داری", "b-52", 
             "ماشین استاد شماخی", "bomber tu-95", "f-14 tomkat", "f-35 lighting", "f-22 raptor");
echo "<pre>";
print_r($car);


echo "<br>";

$num1 = 10 ;
$num2 = 100 ;

if ($num1 == $num2) {
    echo "نمرات برابر هستند!<br>";
}

if ($num1 >= $num2) {
    echo "نمره اول بزرگتر یا مساوی نمره دوم است!<br>";
}

if ($num1 !== $num2) {
    echo "نمرات از نظر نوع یا مقدار متفاوت هستند!";
} else {
    echo "نمرات کاملاً برابر هستند (هم نوع)!";
}
 echo "<br>";


$num1 = 20;
$num2 = 5;

echo "عدد اول: $num1<br>";
echo "عدد دوم: $num2<br><br>";

$sum = $num1 + $num2;
echo "جمع: $num1 + $num2 = $sum<br>";

$sub = $num1 - $num2;
echo "تفریق: $num1 - $num2 = $sub<br>";

$mul = $num1 * $num2;
echo "ضرب: $num1 * $num2 = $mul<br>";

$div = $num1 / $num2;
echo "تقسیم: $num1 / $num2 = $div<br>";

$mod = $num1 % $num2;
echo "باقیمانده تقسیم: $num1 % $num2 = $mod<br>";

$pow = $num1 ** $num2;
echo "توان: $num1 ** $num2 = $pow<br>"

?>

