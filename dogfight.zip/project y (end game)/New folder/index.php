<?php
$ok = false;
$error='';
 $user_db='';
 $pass_db='';

if(isset($_POST['user'])){
    $file=fopen('db.txt','r');

    $user=$_POST['user'];
    $pass=$_POST['pass'];

    for($i=1;$i<=2;$i++){
        $oufile=fgets($file);
        $read1=explode( "," , $oufile);
        $user_db=$read1[0];
        $pass_db=$read1[1];
        $mobile=$read1[2];
        $namefull=$read1[3];

    if($user == $user_db && $pass == $pass_db){
        $ok=true;
        
    }else{
        $error='نام کاربری یا رمز عبور اشتباه است';
        }}


    fclose($file);
}




?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>j10</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <div class="div1">
        
            <form action="index.php" method="post">
            <label for="user">username</label><br>
            <input type="text" name="user" id="suer"  placeholder="insert your username"><br>
            
            <label for="pass">password</label><br>
            <input type="password" name="pass" id="pass"  placeholder="insert your password"><br>
            
            <button type="submit">sign in</button>
            <p>Do you have not an account? <a href="reg.php">click here!</a></p>
        </form>
    </div>

    <br>
    <?php
    
            if($ok){
                echo '
                    <div style="background-color: green;color: while;text-align: center; width: 300px;margin:auto;border-radius:10px;">شناسایی شما با موفقیت انجام شد.اکنون وارد سایت می شوید</div>
                    <meta http-equiv="refresh" content="4; url=home.html">
                ';
            }else{
                echo '
                    <div style="background-color: red;color: while;text-align: center;width: 300px;margin:auto;border-radius:10px;">'.$error.'</div>
                ';
            }
        ?>
</body>
</html>