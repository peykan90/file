<?php
$db = mysqli_connect("localhost", "root", "", "azarpeykan");

if (!$db) {
    die("اتصال ناموفق: " . mysqli_connect_error());
}

$ok = false;
$error = '';

if (isset($_POST['user'])) {
    $user = mysqli_real_escape_string($db, $_POST['user']);
    $pass = mysqli_real_escape_string($db, $_POST['pass']);
    $mobile = mysqli_real_escape_string($db, $_POST['mobile']);
    $namefull = mysqli_real_escape_string($db, $_POST['namefull']);

    // اعتبارسنجی
    if (strlen($user) < 3 || strlen($user) > 20) {
        $error = 'نام کاربری باید بین ۳ تا ۲۰ کاراکتر باشد.';
    } elseif (strlen($pass) < 8) {
        $error = 'رمز عبور باید حداقل ۸ کاراکتر باشد.';
    } elseif (strlen($mobile) != 11 || substr($mobile, 0, 2) != '09') {
        $error = 'شماره موبایل معتبر نیست.';
    } elseif (strlen($namefull) < 3 || strlen($namefull) > 50) {
        $error = 'نام و نام خانوادگی معتبر نیست.';
    } else {
        // ثبت در دیتابیس
        $sql = "INSERT INTO user (username, pass, mobile, namefull) VALUES ('$user', '$pass', '$mobile', '$namefull')";
        if (mysqli_query($db, $sql)) {
            $ok = true;
        } else {
            $error = "خطا در ثبت اطلاعات: " . mysqli_error($db);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>ثبت‌نام</title>
    <link rel="stylesheet" href="reg.css">
</head>
<body>
    <div class="div1">
        <form action="reg.php" method="post">
            <h2>فرم ثبت‌نام</h2>
            <input type="text" name="user" placeholder="نام کاربری" required>
            <input type="password" name="pass" placeholder="رمز عبور" required>
            <input type="tel" name="mobile" placeholder="موبایل" required>
            <input type="text" name="namefull" placeholder="نام و نام خانوادگی" required>
            <button type="submit">ثبت‌نام</button>
            <p><a href="index.php">بازگشت به صفحه اصلی</a></p>
        </form>
        <?php if ($ok): ?>
            <div class="success">ثبت‌نام با موفقیت انجام شد.</div>
        <?php elseif ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
    </div>
</body>
</html>