<?php
include('db.php');

// جلوگیری از SQL Injection
if (isset($_GET['del'])) {
    $del_id = mysqli_real_escape_string($db, $_GET['del']);
    mysqli_query($db, "UPDATE products SET del = 1 WHERE id = '$del_id'");
}

if (isset($_GET['productname'])) {
    $productname = mysqli_real_escape_string($db, $_GET['productname']);
    $productCdate = mysqli_real_escape_string($db, $_GET['productCdate']);
    $count = mysqli_real_escape_string($db, $_GET['count']);
    $price = mysqli_real_escape_string($db, $_GET['price']);
    mysqli_query($db, "INSERT INTO products (product_name, product_cdate, count, price) VALUES ('$productname', '$productCdate', '$count', '$price')");
}

if (isset($_GET['update_id'])) {
    $update_id = mysqli_real_escape_string($db, $_GET['update_id']);
    $product_name = mysqli_real_escape_string($db, $_GET['product_name']);
    $product_cdate = mysqli_real_escape_string($db, $_GET['product_cdate']);
    $price = mysqli_real_escape_string($db, $_GET['price']);
    $count = mysqli_real_escape_string($db, $_GET['count']);
    mysqli_query($db, "UPDATE products SET product_name='$product_name', product_cdate='$product_cdate', price='$price', count='$count' WHERE id='$update_id'");
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>مدیریت محصولات</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="product.css">
</head>
<body>
    <ul>
        <li style="float:right"><a href=""><img width="20" src="icon.png" alt="logo"></a></li>
        <li><a href="role.html">قوانین</a></li>
        <li><a href="home.php">بازگشت</a></li>
        <li><a href="logout.php">خروج</a></li>
        <li><a href="upload.php">آپلود عکس</a></li>
    </ul>
    <div class="container mt-4">
        <h2>مدیریت محصولات</h2>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>ردیف</th>
                    <th>نام محصول</th>
                    <th>تاریخ تولید</th>
                    <th>تعداد</th>
                    <th>قیمت</th>
                    <th>ابزارها</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $result = mysqli_query($db, "SELECT * FROM products WHERE del = 0");
                $i = 0;
                while ($row = mysqli_fetch_assoc($result)):
                    $i++;
                    $id = $row['id'];
                    $pname = htmlspecialchars($row['product_name']);
                    $pdate = htmlspecialchars($row['product_cdate']);
                    $pcount = htmlspecialchars($row['count']);
                    $pprice = htmlspecialchars($row['price']);
                ?>
                <tr>
                    <td><?php echo $i; ?></td>
                    <td><?php echo $pname; ?></td>
                    <td><?php echo $pdate; ?></td>
                    <td><?php echo $pcount; ?></td>
                    <td><?php echo $pprice; ?></td>
                    <td>
                        <a class="btn btn-danger btn-sm" href="product.php?del=<?php echo $id; ?>" onclick="return confirm('حذف شود؟')">حذف</a>
                        <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#modal<?php echo $id; ?>">ویرایش</button>
                    </td>
                </tr>
                <!-- مودال ویرایش -->
                <div class="modal fade" id="modal<?php echo $id; ?>">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form action="product.php" method="get">
                                <input type="hidden" name="update_id" value="<?php echo $id; ?>">
                                <div class="modal-body">
                                    <input type="text" name="product_name" value="<?php echo $pname; ?>" class="form-control mb-2">
                                    <input type="number" name="product_cdate" value="<?php echo $pdate; ?>" class="form-control mb-2">
                                    <input type="number" name="count" value="<?php echo $pcount; ?>" class="form-control mb-2">
                                    <input type="number" name="price" value="<?php echo $pprice; ?>" class="form-control mb-2">
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary">ذخیره</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            </tbody>
        </table>
        <!-- دکمه افزودن -->
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addmodal">افزودن محصول</button>
        <!-- مودال افزودن -->
        <div class="modal fade" id="addmodal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="product.php" method="get">
                        <div class="modal-body">
                            <input type="text" name="productname" placeholder="نام محصول" class="form-control mb-2" required>
                            <input type="number" name="productCdate" placeholder="تاریخ تولید" class="form-control mb-2" required>
                            <input type="number" name="count" placeholder="تعداد" class="form-control mb-2" required>
                            <input type="number" name="price" placeholder="قیمت" class="form-control mb-2" required>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success">ثبت</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>