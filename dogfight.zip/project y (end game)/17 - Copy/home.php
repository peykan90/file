<?php
include('db.php');

// نام کاربر مهمان (بدون Session)
$namefull = "کاربر مهمان";
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>صفحه اصلی آذرپیکان</title>
    <link rel="stylesheet" href="home.css">
</head>
<body>
    <ul>
        <li style="float:right"><a href=""><img width="20" src="icon.png" alt="logo"></a></li>
        <li><a href="product.php">مشاهده لیست محصولات</a></li>
        <li><a href="users.php">مشاهده کاربران</a></li>
        <li><a href="logout.php">خروج</a></li>
    </ul>
    <p class="p1"><?php echo htmlspecialchars($namefull); ?> به سایت ما خوش آمدید</p>
    <div class="container">
        <iframe src="users.php" width="400" height="400" frameborder="0"></iframe>
        <iframe src="product.php" width="400" height="400" frameborder="0"></iframe>
        <iframe src="role.html" width="400" height="400" frameborder="0"></iframe>
    </div>
</body>
</html>