<?php
// بدون Session و Cookie - فقط یک پیام ساده
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="3; url=index.php">
    <title>خروج</title>
    <style>
        body { font-family: sans-serif; background: #f4f4f4; text-align: center; padding-top: 20%; }
        .logout { font-size: 24px; color: #333; }
    </style>
</head>
<body>
    <div class="logout">از حساب خارج شدید. در حال انتقال به صفحه اصلی...</div>
</body>
</html>