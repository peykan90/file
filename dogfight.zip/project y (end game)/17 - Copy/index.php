<?php
// بدون Session و Cookie
header("Location: home.php");
exit;
?>