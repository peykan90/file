<?php
// اتصال به دیتابیس
$db = mysqli_connect("localhost", "root", "", "azarpeykan");

if (!$db) {
    die("اتصال به دیتابیس برقرار نشد: " . mysqli_connect_error());
}

// تنظیم ناحیه زمانی
date_default_timezone_set('Asia/Tehran');
mysqli_query($db, "SET time_zone = '+3:30'");

// تنظیم کاراکترها
mysqli_set_charset($db, "utf8");
?>