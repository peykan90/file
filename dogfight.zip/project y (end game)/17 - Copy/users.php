<?php
include('db.php');

if (isset($_GET['del'])) {
    $del_id = mysqli_real_escape_string($db, $_GET['del']);
    mysqli_query($db, "UPDATE user SET del = 1 WHERE id = '$del_id'");
}

if (isset($_GET['user_name'])) {
    $user = mysqli_real_escape_string($db, $_GET['user_name']);
    $pass = mysqli_real_escape_string($db, $_GET['pass']);
    $phone = mysqli_real_escape_string($db, $_GET['phone']);
    $fullname = mysqli_real_escape_string($db, $_GET['fullname']);
    mysqli_query($db, "INSERT INTO user (username, pass, mobile, namefull) VALUES ('$user', '$pass', '$phone', '$fullname')");
}

if (isset($_GET['update_id'])) {
    $id = mysqli_real_escape_string($db, $_GET['update_id']);
    $username = mysqli_real_escape_string($db, $_GET['update_user_name']);
    $phone = mysqli_real_escape_string($db, $_GET['update_phone']);
    $fullname = mysqli_real_escape_string($db, $_GET['update_fullname']);
    mysqli_query($db, "UPDATE user SET username='$username', mobile='$phone', namefull='$fullname' WHERE id='$id'");
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>کاربران</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="user.css">
</head>
<body>
    <ul>
        <li style="float:right"><a href=""><img width="20" src="icon.png" alt="logo"></a></li>
        <li><a href="product.php">محصولات</a></li>
        <li><a href="home.php">بازگشت</a></li>
        <li><a href="logout.php">خروج</a></li>
    </ul>
    <div class="container mt-4">
        <h2>لیست کاربران</h2>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>ردیف</th>
                    <th>نام و نام خانوادگی</th>
                    <th>نام کاربری</th>
                    <th>موبایل</th>
                    <th>ابزارها</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $result = mysqli_query($db, "SELECT * FROM user WHERE del = 0");
                $i = 0;
                while ($row = mysqli_fetch_assoc($result)):
                    $i++;
                    $id = $row['id'];
                    $name = htmlspecialchars($row['namefull']);
                    $uname = htmlspecialchars($row['username']);
                    $mobile = htmlspecialchars($row['mobile']);
                ?>
                <tr>
                    <td><?php echo $i; ?></td>
                    <td><?php echo $name; ?></td>
                    <td><?php echo $uname; ?></td>
                    <td><?php echo $mobile; ?></td>
                    <td>
                        <a class="btn btn-danger btn-sm" href="users.php?del=<?php echo $id; ?>" onclick="return confirm('حذف؟')">حذف</a>
                        <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#edit<?php echo $id; ?>">ویرایش</button>
                    </td>
                </tr>
                <!-- مودال ویرایش -->
                <div class="modal fade" id="edit<?php echo $id; ?>">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form action="users.php" method="get">
                                <input type="hidden" name="update_id" value="<?php echo $id; ?>">
                                <div class="modal-body">
                                    <input type="text" name="update_user_name" value="<?php echo $uname; ?>" class="form-control mb-2">
                                    <input type="tel" name="update_phone" value="<?php echo $mobile; ?>" class="form-control mb-2">
                                    <input type="text" name="update_fullname" value="<?php echo $name; ?>" class="form-control mb-2">
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary">ذخیره</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            </tbody>
        </table>
        <!-- دکمه افزودن -->
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#adduser">افزودن کاربر</button>
        <!-- مودال افزودن -->
        <div class="modal fade" id="adduser">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="users.php" method="get">
                        <div class="modal-body">
                            <input type="text" name="user_name" placeholder="نام کاربری" class="form-control mb-2" required>
                            <input type="password" name="pass" placeholder="رمز عبور" class="form-control mb-2" required>
                            <input type="tel" name="phone" placeholder="موبایل" class="form-control mb-2" required>
                            <input type="text" name="fullname" placeholder="نام و نام خانوادگی" class="form-control mb-2" required>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success">ثبت</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>