    let timer=new Date()
        let s=timer.getSeconds()
        let m=timer.getMinutes()
        let h=timer.getHours()


        function showtime(){

            let timer=new Date()
        let s=timer.getSeconds()
        let m=timer.getMinutes()
        let h=timer.getHours()



            if(h==0){h=24}
            if(h>23){h=h-24}


            s=(s<10)?'0'+s :s
            m=(m<10)?'0'+m :m
            h=(h<10)?'0'+h :h


            document.getElementById('show').innerText= h + ':' + m + ":" +s

            setTimeout(showtime,1000)
        }
        showtime()