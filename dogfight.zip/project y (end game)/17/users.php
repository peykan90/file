<?php 
stream_socket_sendto();
$db = mysqli_connect("localhost", "root", "", "azarpeykan");

// عملیات حذف کاربر (Soft Delete)
if (isset($_GET['del'])) {
    $del_id = $_GET['del'];
    $sql = mysqli_query($db, "update user set del='1' where id = '$del_id'");
}

// عملیات ثبت کاربر جدید
if (isset($_GET['user_name'])) {
    $user = $_GET['user_name'];
    $pass = $_GET['pass'];
    $phone = $_GET['phone'];
    $fullname = $_GET['fullname'];
    $sql = mysqli_query($db, "insert into user (username, pass, mobile, namefull) values ('$user', '$pass', '$phone', '$fullname')");
}

// عملیات ویرایش مشخصات کاربر بر اساس شناسه دریافتی
if (isset($_GET['update_id'])) {
    $update_id = $_GET['update_id'];
    $update_user = $_GET['update_user_name'];
    $update_phone = $_GET['update_phone'];
    $update_fullname = $_GET['update_fullname'];
    
    $sql = mysqli_query($db, "update user set 
        username = '$update_user', 
        mobile = '$update_phone', 
        namefull = '$update_fullname' 
        where id = '$update_id'");
}
?>
<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>صفحه مشخصات کاربری</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="user.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <ul>
        <li style="float:right"><a href=""><img width="20" src="icon.png" alt="logo"></a></li>
        <li><a href="product.php">مشاهده لیست محصولات</a></li>
        <li><a href="home.php">بازگشت به منو قبل</a></li>
        <li><a href="logout.php">خروج از حساب کاربری</a></li>
    </ul>

    <!-- مودال افزودن کاربر جدید -->
    <div class="modal fade" id="addperson" tabindex="-1" aria-labelledby="addPersonLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="users.php" method="get">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="addPersonLabel">فرم ثبت نام کاربر</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body" >
                        <div class="mb-3">
                            <label for="username" class="form-label">نام کاربری</label>
                            <input type="text" name="user_name" id="username" class="form-control" autocomplete="off" required>
                        </div>
                        <div class="mb-3">
                            <label for="pass" class="form-label">رمز عبور</label>
                            <input type="password" name="pass" id="pass" class="form-control" autocomplete="off" required>
                        </div>
                        <div class="mb-3">
                            <label for="phone" class="form-label">موبایل</label>
                            <input type="tel" name="phone" id="phone" class="form-control" autocomplete="off" required>
                        </div>
                        <div class="mb-3">
                            <label for="fullname" class="form-label">نام و نام خانوادگی</label>
                            <input type="text" name="fullname" id="fullname" class="form-control" autocomplete="off" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">انصراف</button>
                        <button type="submit" class="btn btn-success">ثبت نام</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="div1 container mt-4">
        <h2>در جدول زیر کاربران ثبت نام شده نمایش داده می‌شوند</h2>
        <br>
        <div>
            <table class="table table-bordered table-striped table-hover table-warning text-center align-middle">
                <thead>
                    <tr>
                        <th>ردیف</th>
                        <th>نام و نام خانوادگی</th>
                        <th>نام کاربری</th>
                        <th>موبایل</th> 
                        <th>
                            ابزارها 
                            <button type="button" class="btn btn-success btn-sm ms-2" data-bs-toggle="modal" data-bs-target="#addperson">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-plus" viewBox="0 0 16 16">
                                    <path d="M6 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6m2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0m4 8c0 1-1 1-1 1H1s-1 0-1-1 1-4 6-4 6 3 6 4m-1-.004c-.001-.246-.154-.986-.832-1.664C9.516 10.68 8.289 10 6 10s-3.516.68-4.168 1.332c-.678.678-.83 1.418-.832 1.664z"/>
                                    <path fill-rule="evenodd" d="M13.5 5a.5.5 0 0 1 .5.5V7h1.5a.5.5 0 0 1 0 1H14v1.5a.5.5 0 0 1-1 0V8h-1.5a.5.5 0 0 1 0-1H13V5.5a.5.5 0 0 1 .5-.5"/>
                                </svg>
                            </button> 
                        </th>  
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = mysqli_query($db, "select * from user where del='0'");
                    $i = 0;
                    while ($row = mysqli_fetch_assoc($sql)) {
                        $namefull = $row['namefull'];
                        $username = $row['username'];
                        $mobile = $row['mobile'];
                        $id = $row['id'];
                        $i++;
                    ?>
                        <tr>
                            <td><?php echo $i; ?></td>
                            <td><?php echo $namefull; ?></td>
                            <td><?php echo $username; ?></td>
                            <td><?php echo $mobile; ?></td>
                            <td>
                                <!-- دکمه حذف -->
                                <a class="btn btn-danger btn-sm" href="users.php?del=<?php echo $id; ?>" onclick="return confirm('آیا از حذف این کاربر مطمئن هستید؟')">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                                        <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z"/>
                                        <path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z"/>
                                    </svg>
                                </a>

                                <!-- دکمه باز کردن مودال ویرایش مخصوص همین سطر -->
                                <button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#updateperson_<?php echo $id; ?>">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-exposure" viewBox="0 0 16 16">
                                        <path d="M8.5 4a.5.5 0 0 0-1 0v2h-2a.5.5 0 0 0 0 1h2v2a.5.5 0 0 0 1 0V7h2a.5.5 0 0 0 0-1h-2zm-3 7a.5.5 0 0 0 0 1h5a.5.5 0 0 0 0-1z"/>
                                        <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0M1 8a7 7 0 1 1 14 0A7 7 0 0 1 1 8"/>
                                    </svg>
                                </button> 
                            </td>
                        </tr>

                        <!-- مودال ویرایش اختصاصی این کاربر -->
                        <div class="modal fade" id="updateperson_<?php echo $id; ?>" tabindex="-1" aria-labelledby="updateModalLabel_<?php echo $id; ?>" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form action="users.php" method="get">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="updateModalLabel_<?php echo $id; ?>">ویرایش کاربر: <?php echo $namefull; ?></h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body text-start">
                                            <!-- ارسال ID کاربر برای آپدیت دقیق -->
                                            <input type="hidden" name="update_id" value="<?php echo $id; ?>">

                                            <div class="mb-3">
                                                <label class="form-label">نام کاربری</label>
                                                <input type="text" name="update_user_name" class="form-control" value="<?php echo $username; ?>" autocomplete="off" required>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label">شماره موبایل</label>
                                                <input type="tel" name="update_phone" class="form-control" value="<?php echo $mobile; ?>" autocomplete="off" required>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label">نام و نام خانوادگی</label>
                                                <input type="text" name="update_fullname" class="form-control" value="<?php echo $namefull; ?>" autocomplete="off" required>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">انصراف</button>
                                            <button type="submit" class="btn btn-warning">ذخیره تغییرات</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php 
                    } 
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
