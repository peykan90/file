<?php
    $db=mysqli_connect("localhost","root","","azarpeykan");
   

    session_start();
    $ok=false;
    $error='';

    if(isset($_POST['user'])){
        $user=$_POST["user"];
        $pass=$_POST["pass"];
        $mobile=$_POST["mobile"];
        $namefull=$_POST["namefull"];
    

    if(strlen($user) <3 || strlen($user) >20){
        $error='مقدار وارد شده در نام کاربری کمتر یا بیشتر از حد مجاز است';
    }
    if(strlen($pass)<8){
        $error = 'رمز عبور معتبر نمی باشد ';
    }
    if(strlen($mobile)!= 11){
        $error = 'شماره وارد شده معتبر نمی باشد.';
    }
    if(substr($mobile,0,2)!='09'){
        $error = "شماره تماس وارد شده معتبر نمی باشد ";
    }

    if(strlen($namefull)<3 || strlen($namefull)>50){
        $error="نام و نام خانوادگی اشتباه وارد شده است";
    }

    if($error===''){
        // $outfile=fopen('db.txt','w');
        // $outfile=fopen('db.txt','a');
        // $file=fwrite($outfile,$user .",".$pass.",".$mobile.",".$namefull.PHP_EOL);
        mysqli_query($db,"insert into `user` (username , pass , mobile , namefull)values('$user' , '$pass' , '$mobile' , '$namefull')");

        $_SESSION['mobile'] = $mobile;
        $_SESSION['namefull'] = $namefull;
        setcookie('mobile', $mobile, time() + (86400 * 30), "/"); // 86400 = 1 day
        setcookie('namefull', $namefull, time() + (86400 * 30), "/");
        $ok=true;
    

    }
    
    }

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>j10</title>
    <link rel="stylesheet" href="reg.css">
</head>
<body>
    <div class="div1">
        <!-- <form action="reg_check.php" method="post"> -->
            <form action="reg.php" method="post">
            <label for="user">username</label><br>
            <input type="text" name="user"  placeholder="insert your username" autocomplete="off"><br>
            
            <label for="pass">password</label><br>
            <input type="password" name="pass"  placeholder="insert your password" autocomplete="off"><br>
            
            <label for="mobile">Phone number</label><br>
            <input type="tel" name="mobile"  placeholder="insert your phone number" autocomplete="off"><br>

            <label for="fullname">fullname</label><br>
            <input type="text" name="namefull"  placeholder="insert your full name..." autocomplete="off"><br>
            
            <button type="submit">signup</button>
            <p>Do you have an account? <a href="index.php">click here!</a></p>
        </form>
    </div>
    <!-- <div style="margin: auto;margin-top: 20%; text-align: center;"> -->
    <br>
    <?php
    
            if($ok){
                echo '
                    <div style="background-color: green;color: while;text-align: center; width: 300px;margin:auto;border-radius:10px;">شما با موفقیت ثبت نام شدید.اکنون وارد سایت می شوید</div>
                    <meta http-equiv="refresh" content="3; url=home.php">
                ';
            }else{
                echo '
                    <div style="background-color: red;color: while;text-align: center;width: 300px;margin:auto;border-radius:10px;">'.$error.'</div>
                ';
            }
        ?>
    <!-- </div> -->
    
</body>
</html>