<?php 
session_start();
$db=mysqli_connect("localhost","root","","azarpeykan");
   
?>
<html lang="en" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>صفحه اصلی سایت آذرپیکان</title>
    <link rel="stylesheet" href="home.css">
</head>
<body>
<ul>
    <li style="float:right"><a href=""><img width="20" src="icon.png" alt="logo"></a></li>
    <li><a href="product.php">مشاهده لیست محصولات</a></li>
    <li><a href="users.php">مشاهده کاربران فعال</a></li>
    <li><a href="logout.php">خروج از حساب کاربری</a></li>
    <!-- <li style="float: right;"><a href="">logo</a></li> -->
</ul>


<br><br>
<!-- <p class="p1">< ? php// echo $_SESSION['namefull'];?> به سایت ما خوش آمدید</p> -->
<p class="p1"><?php echo $_SESSION['namefull'];?> به سایت ما خوش آمدید</p>
<br><br>
<iframe src="users.php" width="400" height="400" frameborder="0"></iframe>
<iframe src="product.php" width="400" height="400" frameborder="0"></iframe>
<iframe src="role.html" width="400" height="400" frameborder="0"></iframe>
</body>
</html>