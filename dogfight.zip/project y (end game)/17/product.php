<?php
// اگر بخوایم حتماً دیتابیس متصل بشود
// require('db.php');

// اگر بخوایم در صورت عدم اتصال ارور داشته باشیم ولی صفحه کار کند
include('db.php');

if(isset($_GET['del'])){
    $del_id=$_GET['del'];
    $sql=mysqli_query($db,"update products set del = 1 where id ='$del_id' ");
}
if(isset($_GET['productname'])){
    $productname=$_GET['productname'];
    $productCdate=$_GET['productCdate'];
    $count=$_GET['count'];
    $price=$_GET['price'];
    $sql = mysqli_query($db,"insert into products (product_name , product_cdate , count , price) values ('$productname','$productCdate','$count','$price')");
}

if(isset($_GET['update_id'])){
    $update_id=$_GET['update_id'];
    $product_name = $_GET['product_name'];
    $product_cdate = $_GET['product_cdate'];
    $price = $_GET['price'];
    $count = $_GET['count'];
    $sql = mysqli_query($db,"update products set product_name = '$product_name' , product_cdate ='$product_cdate', price = '$price' , count = '$count' where id = '$update_id' ");
}



?>
<html dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>صفحه گروه بندی محصولات</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="product.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

</head>
<body>
    <div>
        <ul>
        <li style="float:right"><a href=""><img width="20" src="icon.png" alt="logo"></a></li>
        <li><a href="role.html">قوانین و مقررات قبل از خرید</a></li>
        <li><a href="home.php">بازگشت به منو قبل</a></li>
        <li><a href="logout.php">خروج از حساب کاربری</a></li>
        <li ><a href="upload.php">آپلود عکس محصولات</a></li>

        <!-- <li style="float: right;"><a href="">logo</a></li> -->
        </ul>
    </div>

    <div>
        <h2>برای اضافه کردن عکس برای هر محصول ،   <a href="uploads.php">اینجا </a> کلیک کنین</h2>
            <br><br>
            <div>
                <table class="table table-danger table-bordered container text-center ">
                    <thead>
                        <tr>
                            <th>ردیف</th>
                            <th>نام محصول</th>
                            <th>تاریخ تولید </th>
                            <th>تعداد </th>
                            <th>قیمت (تومان)</th>
                            <th>ابزار ها
                                <button type="button" class="btn btn-success btn-sm ms-2" data-bs-toggle="modal" data-bs-target="#addproduct">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus-square" viewBox="0 0 16 16">
                                            <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2z"/>
                                            <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4"/>
                                        </svg>
                                </button>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                            <?php
                                $sql=mysqli_query($db,"select * from products where del = '0'");
                                    $i=0;
                                    while($row=mysqli_fetch_assoc($sql)){
                                        $id = $row['id'];
                                        $product_name=$row['product_name'];
                                        $product_cdate=$row['product_cdate'];
                                        $count = $row['count'];
                                        $price=$row['price'];
                                        $i++;
                                
                            ?>
                        <tr>
                            <td><?php echo "$i";?> </td>
                            <td><?php echo "$product_name";?> </td>
                            <td><?php echo "$product_cdate";?> </td>
                            <td><?php echo "$count";?> </td>
                            <td><?php echo "$price";?>   </td>
                            <td>
                                <a class="btn btn-danger btn-sm" href="product.php?del=<?php echo $id; ?>" onclick="return confirm('آیا از حذف این محصول مطمئن هستید؟')">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                                        <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z"/>
                                        <path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z"/>
                                    </svg>
                                </a>

                                <button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#updateproduct_<?php echo $id; ?>">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-exposure" viewBox="0 0 16 16">
                                        <path d="M8.5 4a.5.5 0 0 0-1 0v2h-2a.5.5 0 0 0 0 1h2v2a.5.5 0 0 0 1 0V7h2a.5.5 0 0 0 0-1h-2zm-3 7a.5.5 0 0 0 0 1h5a.5.5 0 0 0 0-1z"/>
                                        <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0M1 8a7 7 0 1 1 14 0A7 7 0 0 1 1 8"/>
                                    </svg>
                                </button> 
                            </td>
                        </tr>
                        
        <!-- update product modal -->
              <div class="modal fade" id="updateproduct_<?php echo $id; ?>" tabindex="-1" aria-labelledby="updateModalLabel_<?php echo $id; ?>" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form action="product.php" method="get">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="updateModalLabel_<?php echo $id; ?>">ویرایش محصولات: <?php echo $product_name; ?></h1>
                                            <button type="button" class="btn-close" style="margin-right: 280px;" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body text-start">
                                            <!-- ارسال ID کاربر برای آپدیت دقیق -->
                                            <input type="hidden" name="update_id" value="<?php echo $id; ?>">

                                            <div class="mb-3">
                                                <label class="form-label">نام محصول</label>
                                                <input type="text" name="product_name" class="form-control" value="<?php echo $product_name; ?>" autocomplete="off" required>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label">تاریخ ساخت محصول</label>
                                                <input type="number" name="product_cdate" class="form-control" value="<?php echo $product_cdate; ?>" autocomplete="off" required>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label">تعداد</label>
                                                <input type="number" name="count" class="form-control" value="<?php echo $count; ?>" autocomplete="off" required>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label">قیمت</label>
                                                <input type="number" name="price" class="form-control" value="<?php echo $price; ?>" autocomplete="off" required>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">انصراف</button>
                                            <button type="submit" class="btn btn-warning">ذخیره تغییرات</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
       
                         <?php 
                    } 
                    ?>
                    </tbody>
                </table>
            </div>
    </div>
    


<!-- modals -->
    <!-- add product modal -->
        <div class="modal fade" id="addproduct" tabindex="-1" aria-labelledby="addProductLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="product.php" method="get">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="addProductLabel">فرم ثبت محصول</h1>
                            <button type="button" class="btn-close" style="margin-right: 280px;" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="productname" class="form-label">نام محصول</label>
                                <input type="text" name="productname" id="productname" class="form-control" autocomplete="off" required>
                            </div>
                            <div class="mb-3">
                                <label for="productCdate" class="form-label">تاریخ تولید محصول</label>
                                <input type="number" name="productCdate" id="productCdate" class="form-control" autocomplete="off" required>
                            </div>
                            <div class="mb-3">
                                <label for="count" class="form-label">تعداد</label>
                                <input type="number" name="count" id="count" class="form-control" autocomplete="off" required>
                            </div>
                            <div class="mb-3">
                                <label for="price" class="form-label">قیمت</label>
                                <input type="text" name="price" id="price" class="form-control" autocomplete="off" required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">انصراف</button>
                            <button type="submit" class="btn btn-success">ثبت محصول</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!--  -->            

</body>
</html>