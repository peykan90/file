<?php
$db=mysqli_connect("localhost","root","","azarpeykan");
session_start();

if(isset($_COOKIE['mobile'])&& strlen($_COOKIE['mobile'])==11){
    echo '<meta http-equiv="refresh" content="4; url=home.php">';
    die('به صفحه اصلی منتفل می شوید.');
}
// else{
//     // $_SESSION["mobile"]='';
//     // $_SESSION["namefull"]="";
//     $_COOKIE["namefull"]="";
//     $_COOKIE['mobile']='';
//     }




$ok = false;
$error='';
//  $user_db='';
//  $pass_db='';

if(isset($_POST['user'])){


    $user=$_POST['user'];
    $pass=$_POST['pass'];

    $sql_select=mysqli_query($db,"select * from `user` where username= '$user' and pass='$pass' ");

        if($row=mysqli_fetch_assoc($sql_select)){
            $username=$row['username'];
            $mobile=$row['mobile'];
            $namefull=$row['namefull'];
            setcookie('mobile', $mobile, time() + (86400 * 30), "/"); // 86400 = 1 day
            setcookie('namefull', $namefull, time() + (86400 * 30), "/"); // 86400 = 1 day
            $_SESSION['mobile']=$mobile;
            $_SESSION['namefull']=$namefull;
            $ok = true;
        }}





?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>j10</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <img src="aiolearn.png" width="150"  style="text-align: center; margin-left:45%; ">
    <div class="div1">
        <!-- <form action="reg_check.php" method="post"> -->
            <form action="index.php" method="post">
            <label for="user">username</label><br>
            <input type="text" name="user" id="suer"  placeholder="insert your username"><br>
            
            <label for="pass">password</label><br>
            <input type="password" name="pass" id="pass"  placeholder="insert your password"><br>
            
            <button type="submit">sign in</button>
            <p>Do you have not an account? <a href="reg.php">click here!</a></p>
        </form>
    </div>
    <!-- <div style="margin: auto;margin-top: 20%; text-align: center;"> -->
    <br>
    <?php
    
            if($ok){
                echo '
                    <div style="background-color: green;color: while;text-align: center; width: 300px;margin:auto;border-radius:10px;">شناسایی شما با موفقیت انجام شد.اکنون وارد سایت می شوید</div>
                    <meta http-equiv="refresh" content="4; url=home.php">
                ';
            }else{
                echo '
                    <div style="background-color: red;color: while;text-align: center;width: 300px;margin:auto;border-radius:10px;">'.$error.'</div>
                ';
            }
        ?>
</body>
</html>