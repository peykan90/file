<?php
// $db=mysqli_connect("localhost","root","","azarpeykan");
session_start();

// پاک کردن تمام متغیرهای Session
$_SESSION = array();

// نابود کردن Session
session_destroy();

// حذف Cookie ها
setcookie('mobile', '', time() - 3600, '/');
setcookie('namefull', '', time() - 3600, '/');


?>
<html lang="en" dir="rtl">
<head>
    <meta http-equiv="refresh" content="3; url=index.php">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>در حال خروج از حساب کاربری</title>
    <style>
        body{
            background-color: yellowgreen;
        }
        .logout{
            text-align: center;
            margin: auto;
            font-family: system-ui;
            margin-top: 20%;
            font-size: 40px;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="logout">
        در حال خروج از حساب کاربری خود می باشید .
        لطفاً تا انتقال به صفحه مربوطه از این صفحه خارج نشوید ...
    </div>
</body>
</html>


