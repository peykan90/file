
const englishToMorseMap = {
    'A': '.-', 'B': '-...', 'C': '-.-.', 'D': '-..', 'E': '.', 'F': '..-.',
    'G': '--.', 'H': '....', 'I': '..', 'J': '.---', 'K': '-.-', 'L': '.-..',
    'M': '--', 'N': '-.', 'O': '---', 'P': '.--.', 'Q': '--.-', 'R': '.-.',
    'S': '...', 'T': '-', 'U': '..-', 'V': '...-', 'W': '.--', 'X': '-..-',
    'Y': '-.--', 'Z': '--..',
    '0': '-----', '1': '.----', '2': '..---', '3': '...--', '4': '....-',
    '5': '.....', '6': '-....', '7': '--...', '8': '---..', '9': '----.',
    '.': '.-.-.-', ',': '--..--', '?': '..--..', '!': '-.-.--', '/': '-..-.',
    ':': '---...', ';': '-.-.-.', '=': '-...-', '+': '.-.-.', '-': '-....-',
    '_': '..--.-', '"': '.-..-.', '(': '-.--.', ')': '-.--.-', '$': '...-..-',
    '@': '.--.-.', '&': '.-...', '\'': '.----.'
};

// نگاشت معکوس: کد مورس → حرف انگلیسی
const morseToEnglishMap = {};
(function buildReverseMap() {
    for (const [char, code] of Object.entries(englishToMorseMap)) {
        morseToEnglishMap[code] = char;
    }
    // فاصله بین کلمات
    morseToEnglishMap['/'] = ' ';
})();

// ============ تشخیص نوع ورودی ============
function isMorseCode(text) {
    // تنها کاراکترهای مجاز: نقطه، خط تیره، اسلش، فاصله
    return /^[.\-\/\s]+$/.test(text.trim());
}


function convertAuto() {
    const input = document.getElementById('inputArea').value.trim();
    const outputEl = document.getElementById('outputArea');

    if (!input) {
        showToast('⚠️ لطفاً متنی وارد کنید');
        outputEl.textContent = '';
        outputEl.classList.remove('has-content');
        return;
    }

    if (isMorseCode(input)) {
       
        const tokens = input.split(/\s+/);
        let result = [];
        for (const token of tokens) {
            if (token === '/') {
                result.push(' ');
            } else if (morseToEnglishMap[token]) {
                result.push(morseToEnglishMap[token]);
            } else if (token === '') {
             
            } else {
                result.push('?');
            }
        }
        let englishText = result.join('').replace(/\s+/g, ' ').trim();
        outputEl.textContent = englishText;
        outputEl.style.direction = 'ltr';
        outputEl.style.textAlign = 'left';
    } else {

        const chars = input.toUpperCase().split('');
        let result = [];
        for (const ch of chars) {
            if (ch === ' ') {
                result.push('/');
            } else if (englishToMorseMap[ch]) {
                result.push(englishToMorseMap[ch]);
            } else {
                result.push('?');
            }
        }
        const morseText = result.filter(c => c !== '').join(' ');
        outputEl.textContent = morseText;
        outputEl.style.direction = 'ltr';
        outputEl.style.textAlign = 'left';
    }

    outputEl.classList.add('has-content');
    showToast('✅ تبدیل انجام شد');
}

function clearAll() {
    document.getElementById('inputArea').value = '';
    const outputEl = document.getElementById('outputArea');
    outputEl.textContent = '';
    outputEl.classList.remove('has-content');
    outputEl.style.direction = 'ltr';
    outputEl.style.textAlign = 'left';
    document.getElementById('inputArea').focus();
}

function copyOutput() {
    const el = document.getElementById('outputArea');
    const text = el.textContent;
    if (!text || text.trim() === '') {
        showToast('⚠️ محتوایی برای کپی وجود ندارد');
        return;
    }
    navigator.clipboard.writeText(text).then(() => {
        showToast('📋 کپی شد!');
    }).catch(() => {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        showToast('📋 کپی شد!');
    });
}

function showToast(message) {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toast._timeout);
    toast._timeout = setTimeout(() => {
        toast.classList.remove('show');
    }, 2000);
}


document.addEventListener('DOMContentLoaded', function() {

    const inputArea = document.getElementById('inputArea');
    inputArea.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && e.ctrlKey) {
            e.preventDefault();
            convertAuto();
        }
    });

    function autoResize(textarea) {
        textarea.style.height = 'auto';
        textarea.style.height = Math.min(textarea.scrollHeight, 200) + 'px';
    }
    inputArea.addEventListener('input', function() { autoResize(this); });
    autoResize(inputArea);
});