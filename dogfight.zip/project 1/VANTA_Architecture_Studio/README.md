# VANTA — Architecture & Spaces

A premium editorial architecture-studio landing page made from scratch with vanilla HTML, CSS and JavaScript.

Features: responsive layout, loading screen, custom cursor, light/dark mode, animated mobile menu, reveal animations, counters, project modal, magnetic-feel interactions and email-copy button.

Open `index.html` directly or use VS Code Live Server.
 
[uweur88]
eeyy 
kir khar too koont
