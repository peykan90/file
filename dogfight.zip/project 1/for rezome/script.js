const menuBtn=document.querySelector('.menu-btn');
const nav=document.querySelector('.nav');
menuBtn.addEventListener('click',()=>nav.classList.toggle('open'));

document.querySelectorAll('.nav a').forEach(a=>a.addEventListener('click',()=>nav.classList.remove('open')));

const themeBtn=document.getElementById('themeBtn');
themeBtn.addEventListener('click',()=>{
  document.body.classList.toggle('light');
  themeBtn.textContent=document.body.classList.contains('light')?'☀':'☾';
});

document.getElementById('contactForm').addEventListener('submit',(e)=>{
  e.preventDefault();
  document.getElementById('formMsg').textContent='Thanks! Your message has been received.';
  e.target.reset();
});
